package com.app.spring.emp;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.app.spring.emp")
public class EmployeeConfig 
{

}
