package com.app.spring.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Student {
	
	@Autowired
	@Qualifier("Maths")
	Teacher tech;
	 
	public void TeacherDetails()
	{
		tech.name();
		tech.teach();
	}

}
