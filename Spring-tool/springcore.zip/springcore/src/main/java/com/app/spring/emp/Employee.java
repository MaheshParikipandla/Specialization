package com.app.spring.emp;

import org.springframework.stereotype.Component;

@Component
public class Employee {
	public void details()
	{
		System.out.println("this is employee details class");
	}

}
