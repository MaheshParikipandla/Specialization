package com.app.spring.student;

import org.springframework.stereotype.Component;

@Component
public class Maths implements Teacher {
	public void name()
	{
		System.out.println("Name of teacher is monica");
	}
	public void teach()
	{
		System.out.println("teacher teaches is maths");
	}
	

}
