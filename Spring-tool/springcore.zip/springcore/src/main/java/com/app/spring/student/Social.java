package com.app.spring.student;

import org.springframework.stereotype.Component;

@Component
public class Social implements Teacher{
	public void name()
	{
		System.out.println("Name of teacher is mahesh");
	}
	public void teach()
	{
		System.out.println("teacher teaches is social");
	}
	

}
