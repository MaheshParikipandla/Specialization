package Demo.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.app.spring.emp.Employee;
import com.app.spring.emp.EmployeeConfig;
import com.app.spring.student.Student;
import com.app.spring.student.StudentConfig;

public class App 
{
    public static void main( String[] args )
    {
    	//Employee
//        ApplicationContext context= new AnnotationConfigApplicationContext(EmployeeConfig.class);
//       Employee emp=(Employee) context.getBean("employee");
//       emp.details();
//       Employee emp1=context.getBean("employee",Employee.class);
//       emp1.details();
//       
       //student
       ApplicationContext context2=new AnnotationConfigApplicationContext(Student.class);
       Student stu=(Student) context2.getBean("student1");
       stu.TeacherDetails();
    }
}
