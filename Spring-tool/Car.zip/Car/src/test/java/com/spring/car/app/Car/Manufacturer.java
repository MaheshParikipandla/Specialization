package com.spring.car.app.Car;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Manufacturer {
	
@Autowired
Car car;
public void buildCar()
{
	car.demo();
}

}
