package com.spring.car.app.Car;

import org.springframework.stereotype.Component;

@Component
public class Bmw extends Car{
	public void demo() 
	{
		System.out.println("BMW cars");
	}
	
	

}
