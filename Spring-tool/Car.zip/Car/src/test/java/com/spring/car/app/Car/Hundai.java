package com.spring.car.app.Car;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
public class Hundai extends Car{
	public void demo() 
	{
		System.out.println("Hundai cars");
	}
	

}
