package com.spring.car.app.Car;

public abstract class Car {
	
	public void demo()
	{
		
	}
	public void getMusic()
	{
		System.out.println("music added");
	}
	

}
