// var http=require('http')
var fs=require('fs')
// const res = require('express/lib/response')



// http.createServer((req,res)=>{
// res.write('<h1>helloo</h1>')



// fs.readFile('abc.txt','utf-8',function(err,data){
// res.write(data)
// res.end()
// })
// }).listen(4202,(req,res)=>{
// console.log('running........')
// })




// fs.readFile('./file1.js','utf-8',function(err,data){
// console.log(data)
// })



//  fs.writeFile('file1.js',"console.log('demo txt...')",function(err){
//  console.log('file created')
//  })



fs.writeFile('xyz.txt',"console.log('demo text in xyz...')",function(err)
{
console.log('file created')
})



// fs.appendFile('abc.txt',"console.log('demo append txt in abc')",function(err){
// console.log('file created')
// })
// fs.unlink('xyz.txt',(err)=>{
// console.log(err)
// })