var express = require('express')
const req = require('express/lib/request')



var app=express()
app.get('/',(req,res)=>{
  res.send(`hi this is express`)
})

app.get('/name',(req,res)=>{
    res.send(`hi ur name is sai`)
 })
 app.get('/names',(req,res)=>{
    var id=req.query.id;
    res.send(`hi this using query pattern ${id} express`)
 })


app.get('/name/:id',(req,res)=>{
var id=req.params.id;
var name;
if(id==1)
{
    name="mahesh";
}
else if(id==2)
{
    name="monica";
}
else{
    name="sai"
}


    res.send(`hi ${name} ur id is ${id}`)
})

app.listen(8081,(req,res)=>{
    console.log('server started')
})
