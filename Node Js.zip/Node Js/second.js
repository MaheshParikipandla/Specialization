var calc=require('./calculator.js')
var result=calc.add(10,10);
var res=calc.sub(20,10);

console.log(`addition is ${result}`);
console.log(`addition is ${res}`);