var express=require("express")
var app=express();

app.get('/submit',(req,res)=>{
    var name=req.query.name;
    var age=req.query.age;
    res.send(`hi ${name} age is ${age}`);
})
app.listen(8088,()=>{
    console.log('server is running')
})