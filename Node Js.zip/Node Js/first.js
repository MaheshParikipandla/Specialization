var http=require("http");

http.createServer((req,res)=>
{
    res.write('<h1>Hi,Welcome</h1>');
    res.end();
    console.log('Server started');
}).listen(3000)
