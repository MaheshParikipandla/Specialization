var EventEmitter=require('events')



var emitter=new EventEmitter()



emitter.on('call a listener1',()=>{

    console.log('Listener is called....!1')
})


emitter.emit('call a listener1')

function spraywater()
    {
        console.log('spraywater function');
    }
    
    emitter.on('fire',spraywater);
    emitter.emit('fire');


function extinguisher()
{
    console.log("extinguisher fun");
}

emitter.addListener('spray',extinguisher)

emitter.emit('spray');