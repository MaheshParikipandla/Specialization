package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.example.demo.EmpService;
import com.example.demo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentController {

@Autowired
EmpService service;

	@RequestMapping("/")
	public String dem()
	{
		return "index.jsp";
	}
	
	
	@RequestMapping("/print")
	public ModelAndView demo(@RequestParam("name") String name, String designation ,ModelAndView mv)
	{
		mv.setViewName("welcome.jsp");
		mv.addObject("username",name);
		mv.addObject("designation",designation);
		return mv;
	}
	@RequestMapping("/save")
	public ModelAndView empSave(ModelAndView mv, Employee emp)
	{
		mv.setViewName("welcome.jsp");
		mv.addObject("emp",emp);
		service.saveEmp(emp);
		return mv;
	}
	
}
