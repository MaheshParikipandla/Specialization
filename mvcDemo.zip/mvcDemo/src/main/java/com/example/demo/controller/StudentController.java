package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.example.demo.EmpService;
import com.example.demo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;

import java.util.List;

@Controller
public class StudentController {

@Autowired
EmpService service;

//	@RequestMapping("/")
//	public String dem()
//	{
//		return "index.jsp";
//	}
	
	
	@RequestMapping("/print")
	public ModelAndView demo(@RequestParam("name") String name, ModelAndView mv)
	{
		mv.setViewName("welcome.jsp");
		mv.addObject("username",name);
		//mv.addObject("designation",designation);
		return mv;
	}
	@RequestMapping(value="/save" ,method= RequestMethod.POST)
	public ModelAndView empSave(ModelAndView mv, Employee emp)
	{
		mv.setViewName("welcome.jsp");
		List<Employee> list=service.getEmployees();
		mv.addObject("all",list);

		service.saveEmp(emp);
		return mv;
	}
	@RequestMapping("/")
	public ModelAndView dem(ModelAndView mv)
	{
		mv.setViewName("index.jsp");
		return mv;
	}
	@RequestMapping("/delete")
	public ModelAndView empdel(ModelAndView mv , Employee emp)
	{ mv.setViewName("delete.jsp");



		return mv;
	}
	
}
