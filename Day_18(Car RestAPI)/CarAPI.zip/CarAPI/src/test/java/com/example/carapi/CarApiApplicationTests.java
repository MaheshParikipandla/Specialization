package com.example.carapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
