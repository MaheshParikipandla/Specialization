var cars=["hundai","BMW","Tata"];
cars[3]="Benze";
cars.push("duster");
cars.pop();
for(var i=0;i<cars.length;i++)
{
    console.log(cars[i]);
}
console.log('_________________');

var fruits=new Array();
fruits[0]="banana";
fruits[1]="apple";
fruits[2]="orange";
fruits.sort();
fruits.sort().reverse;
for(const items of fruits)
{
    console.log(items);
}
console.log('_________________');

for(const items in fruits)
{
    console.log(items);
}
var date=new Date();
console.log(date);
console.log(date.getDate());
console.log(date.getDay());
console.log(date.getFullYear());
console.log(date.getHours())
console.log(date.getTime());;

// function abc()
// {
//     this.name="Hii mahesh";
//     console.log(this.name);
//     console.log(this.name.toLocaleLowerCase());
//     console.log(this.name.toLocaleUpperCase());
//     this.name=this.name.concat(" and monica");
//     console.log(this.name);
//     console.log(this.name.slice(0,9));
//     this.name=this.name.replace('and','or');
//     console.log(this.name);
//     console.log(this.name.lastIndexOf('monica'));
//     console.log(this.name.startsWith('Hii'));
//     console.log(this.name.endsWith('monica'));
// }
// abc();