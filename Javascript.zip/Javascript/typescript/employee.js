var v = {
    id: 1,
    name: 'Mahesh',
    city: 'warangal',
    pincode: 506001,
    display: function () {
        console.log("this is demo text.");
    }
};
console.log("this is json implementation");
console.log("name is ".concat(v.name, " and city is ").concat(v.city));
var Manager = /** @class */ (function () {
    function Manager(id, name, city, pincode) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.pincode = pincode;
    }
    Manager.prototype.display = function () {
        console.log("name is ".concat(this.name, " and I'm from ").concat(this.city));
    };
    return Manager;
}());
console.log("object implememnation");
var employee = new Manager(1, 'mahesh', 'banglore', 12333);
employee.display();
