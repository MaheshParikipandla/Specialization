interface address
{
    city:string;
    pincode:number;
}

interface Employee extends address{
    id:number;
    name:string;
    display():void;
}
var v:Employee={
    id: 1,
    name: 'Mahesh',
    city: 'warangal',
    pincode: 506001,
    display: function (): void {
        console.log("this is demo text.");
    }
};
console.log("this is json implementation");
console.log(`name is ${v.name} and city is ${v.city}`);
class Manager implements Employee
{
    
    id: number;
    name: string;
    city: string;
    pincode: number;
    constructor(id:number,name:string,city:string,pincode:number)
    {
        this.id=id;
        this.name=name;
        this.city=city;
        this.pincode=pincode;
    }
    display(): void {
        console.log(`name is ${this.name} and I'm from ${this.city}`);
    }

}
console.log("object implememnation");
var employee:Manager =new Manager(1,'mahesh','banglore',12333);
employee.display();