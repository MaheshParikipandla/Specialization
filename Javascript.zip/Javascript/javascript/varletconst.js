function abc(){

    var fruits=["apple","banana","orange","grapes","gauva"]

    let index;

    for(index=0;index<fruits.length;index++){

        var element =fruits[index];

    //    console.log(element);

        // console.log(fruits);

        // console.log(index);
    }

  //  console.log(element);

  //  console.log(fruits);

  //  console.log(index);



}

abc();
//const a=10;
//const b=a;
//console.log(a);
//console.log(b);

var message=`this
                 is 
                mahesh`;
console.log(message);
var a=19;
var b=90;
console.log(`${a+b}`);