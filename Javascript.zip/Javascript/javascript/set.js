class abc{
    constructor()
    {
        setTimeout(()=>{
            console.log('helllo this is 5 sec function');
        },5000)
    }
}
var a=new abc();