package com.example.car_restapi.Controller;

@Controller
public class Controller {
}
