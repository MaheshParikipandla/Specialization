package com.example.car_restapi.Repo;

@Repo
public interface CarRepo extends JpaRepository<Car,Integer>{
}
