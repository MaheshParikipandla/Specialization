package com.example.car_restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarRestApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(CarRestApiApplication.class, args);
    }

}
