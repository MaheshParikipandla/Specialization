var pr=new Promise((resolve,reject)=>{  
condition=false;
if(condition)
{
    console.log('condition fullfilled');
    resolve('transaction successful');
}
else{
    console.log('condition failed');
    reject('transaction is not successful');
}
});

pr.then(success).catch(failure).finally(def)
function success()
{
    console.log('promise is successful');
}
function failure()
{
    console.log('promise is failed');
}
function def()
{
    console.log('finally');
}