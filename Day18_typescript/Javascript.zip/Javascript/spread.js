console.log("spread operator---------");
var arr=[1,2,3,4];
var arr1=[1,2,3,4];
var arr2=[...arr,...arr1];
console.log(...arr2);
let str="hello";
console.log(...str);