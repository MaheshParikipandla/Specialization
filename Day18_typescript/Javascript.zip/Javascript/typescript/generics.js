var arr = [1, 2, 'apple', function () { return 'monica'; }];
console.log(arr);
var arr1 = [1, 2, 3, 4, 5, 6,];
console.log(arr1);
for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
    var i = arr_1[_i];
    console.log(i);
}
