let arr=[1,2,'apple',()=>{return 'monica'}];
console.log(arr);
let arr1:Array<number>=[1,2,3,4,5,6,];
console.log(arr1);
for(const i of arr)
{
    console.log(i);
}
