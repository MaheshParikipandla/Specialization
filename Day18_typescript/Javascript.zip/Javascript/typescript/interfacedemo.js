var emp = { 'name': 'Mahesh', 'age': 21, 'salary': 20000, 'city': 'wgl' };
console.log(emp.city);
var emp1 = { 'name': 'sai', 'age': 21, 'salary': 20000 }; //invoke interface variables
var emp2 = { 'name': 'monica', 'age': 21,
    display: function () { return "this is mahesh"; } };
console.log('****************');
console.log("Employee name:" + emp1.name);
console.log("Employee age:" + emp1.age);
console.log("Employee salary:" + emp1.salary);
console.log('****************');
console.log("Employee name:" + emp2.name);
console.log("Employee age:" + emp2.age);
