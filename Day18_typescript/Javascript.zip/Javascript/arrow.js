
var xyz=(x,y)=>{

    // var a=10;

    // var b=10;

    console.log(`the result is ${x+y}`)

    return x+y;

}

console.log(xyz(10,20));



// function add(x){

//     var a=x;

//     console.log(a);

// }

// add(xyz();)
var xyz=()=>{

    var c=10;

    var d=10;

    console.log(`the result is ${c+d}`)

   // return x+y;

}
//single line code
var x=(e,f)=>e+f
console.log(x(10,20));
