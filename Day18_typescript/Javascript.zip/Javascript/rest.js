console.log('Rest Operator');



function add(...a){

    var a=0;

    for(const i of a){

        a=a+i;

        // console.log(i);

    }

}

add(1,2);

add(1,2,3);

add(1,2,3,4);

add(1,2,3,4,5);