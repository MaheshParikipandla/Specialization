package com.example.bank_restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankRestApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(BankRestApiApplication.class, args);
    }

}
