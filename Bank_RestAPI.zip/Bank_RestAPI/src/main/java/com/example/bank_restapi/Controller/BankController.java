package com.example.bank_restapi.Controller;

import com.example.bank_restapi.Model.User;
import com.example.bank_restapi.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class BankController {
    @Autowired
    UserService service;
    @PostMapping( value = "/saveuser" ,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_XML_VALUE )
    public ResponseEntity<User> print(@RequestBody User user)
    {
        service.store(user);
        return new ResponseEntity<User>(user, HttpStatus.CREATED);
    }

    @GetMapping( value = "/Users" ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<List<User>> getUsers()
    {
        List<User> list=service.getUsers();
        return new ResponseEntity<List<User>>(list,HttpStatus.CREATED);
    }
    @GetMapping( value = "/User/{id}" ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<User> getUser(@PathVariable("id") int id)
    {
        User user=service.getUser(id);
        return new ResponseEntity<User>(user,HttpStatus.CREATED);
    }
}
