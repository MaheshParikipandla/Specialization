import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
flag:boolean=false;
mess:string='';
prop:string='';
  constructor() { }

  ngOnInit(): void {
  }
  changes(){
    if(this.flag){
      this.flag=!this.flag; }
    else{
        this.flag=!this.flag;
      }
}
login(value: any){
  if(value.username=="thanu"&&value.email == "thanu@gmail.com" && value.password == "123"){
  this.mess=`Successfully logged in`;
  this.prop=`#006400`;
  }
  else {
  this.mess=`login not succesful`;
  this.prop=`red`;
  }
  console.log(value.emailid);
  console.log(value.password);
  }
  

}
